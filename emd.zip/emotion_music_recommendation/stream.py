import streamlit as st
import cv2
import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.keras.models import load_model
from PIL import Image
import os

# Load the trained model
model_path = "E:/MY DOWNLOADS/Emotion-Music-Recommendation/emotion_model.h5"
if not os.path.exists(model_path):
    st.error("Model file not found! Ensure 'emotion_model.h5' is in the correct path.")
    st.stop()

model = load_model(model_path)

# Emotion labels mapping
emotion_dict = {0: "Angry", 1: "Disgusted", 2: "Fearful", 3: "Happy", 4: "Neutral", 5: "Sad", 6: "Surprised"}

# Music recommendations for each emotion
music_dict = {
    "Angry": "E:/MY DOWNLOADS/Emotion-Music-Recommendation/songs/angry_with_links.csv",
    "Disgusted": "E:/MY DOWNLOADS/Emotion-Music-Recommendation/songs/disgusted_with_links.csv",
    "Fearful": "E:/MY DOWNLOADS/Emotion-Music-Recommendation/songs/fearful_with_links.csv",
    "Happy": "E:/MY DOWNLOADS/Emotion-Music-Recommendation/songs/happy_with_links.csv",
    "Neutral": "E:/MY DOWNLOADS/Emotion-Music-Recommendation/songs/neutral_with_links.csv",
    "Sad": "E:/MY DOWNLOADS/Emotion-Music-Recommendation/songs/sad_with_links.csv",
    "Surprised": "E:/MY DOWNLOADS/Emotion-Music-Recommendation/songs/surprised_with_links.csv"
}

# Function to detect face and predict emotion
def detect_emotion(image):
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

    if len(faces) == 0:
        return None, image  # No face detected

    for (x, y, w, h) in faces:
        roi_gray = gray[y:y + h, x:x + w]
        roi_gray = cv2.resize(roi_gray, (48, 48))
        roi_gray = np.expand_dims(roi_gray, axis=0).astype("float32") / 255.0
        roi_gray = np.expand_dims(roi_gray, axis=-1)

        prediction = model.predict(roi_gray)
        emotion_index = np.argmax(prediction)
        emotion = emotion_dict[emotion_index]

        # Draw rectangle around face and put emotion label
        cv2.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0), 2)
        cv2.putText(image, emotion, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 0, 0), 2)

    return emotion, image

# Function to recommend a song based on emotion
def recommend_song(emotion):
    if emotion in music_dict:
        file_path = music_dict[emotion]
        if os.path.exists(file_path):
            df = pd.read_csv(file_path)
            if not df.empty:
                return df.sample(n=1)  # Return one random song
    return None

# Streamlit UI
st.set_page_config(page_title="Emotion-Based Music Recommender", page_icon="🎵", layout="wide")

st.markdown("<h1 style='text-align: center; color: orange;'>Emotion-Based Music Recommender 🎵</h1>", unsafe_allow_html=True)
st.markdown("<h3 style='text-align: center; color: white;'>Detect emotions and get song recommendations!</h3>", unsafe_allow_html=True)

# Sidebar options
st.sidebar.markdown("## 📷 Real-Time Emotion Detection")
webcam_btn = st.sidebar.button("Start Webcam")

st.sidebar.markdown("## 📂 Upload an Image")
uploaded_file = st.sidebar.file_uploader("Choose an image...", type=["jpg", "png", "jpeg"])

# Process uploaded image
if uploaded_file is not None:
    image = Image.open(uploaded_file)
    image = np.array(image.convert("RGB"))

    result = detect_emotion(image)

    if result:
        emotion, processed_image = result
        st.image(processed_image, caption=f"Detected Emotion: {emotion}", use_container_width=True)

        song = recommend_song(emotion)
        if song is not None:
            st.markdown(f"### 🎵 Recommended Song for {emotion}:")
            st.dataframe(song)
        else:
            st.warning("No song found for this emotion.")
    else:
        st.warning("No face detected! Please upload a clearer image.")

# Real-time webcam emotion detection inside Streamlit
if webcam_btn:
    st.sidebar.warning("Press 'Stop' to close webcam.")

    cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)  # Use CAP_DSHOW for faster capture on Windows
    cap.set(cv2.CAP_PROP_FPS, 30)  # Increase FPS
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

    frame_placeholder = st.empty()  # Placeholder for displaying frames
    stop_btn = st.sidebar.button("Stop Webcam")

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret or stop_btn:
            break

        # Process frame and detect emotion
        emotion, processed_frame = detect_emotion(frame)

        # Convert image to RGB and display in Streamlit
        processed_frame = cv2.cvtColor(processed_frame, cv2.COLOR_BGR2RGB)
        frame_placeholder.image(processed_frame, channels="RGB", use_column_width=True)

        # Recommend song inside the webcam view
        if emotion:
            song = recommend_song(emotion)
            if song is not None:
                st.sidebar.markdown(f"### 🎵 Recommended Song for {emotion}:")
                st.sidebar.dataframe(song)
    
    cap.release()
    st.sidebar.success("Webcam stopped.")
